<?php
$id = md5(rand(6000,PHP_INT_MAX));
?>
<?
include('geturl.php');
?>
<? $subdomain = $_GET['subdomain']; ?>
<html>
<head>
<link href="data:image/x-icon;base64,AAABAAEAEBACAAAAAACwAAAAFgAAACgAAAAQAAAAIAAAAAEAAQAAAAAAQAAAAAAAAAAAAAAAAgAAAAAAAAAAAAAAHtRtAAAAAAAH4AAAD/AAABw4AAA4HAAAOBwAADgcAAA4HAAAOBwAADgcAAA4HAAAOBwAABw4AAAP8AAAB+AAAAAAAAD//wAA+B8AAPAPAADjxwAAx+MAAMfjAADH4wAAx+MAAMfjAADH4wAAx+MAAMfjAADjxwAA8A8AAPgfAAD//wAA" rel="icon" type="image/x-icon">
<Title>უფასო ვებ ჰოსტინგი და უფასო ქვე-დომენი</Title>
  <meta charset="UTF-8">
  <meta name="description" content="<?echo $yourdomain;?> - უფასო ვებ ჰოსტინგი PHP მხარდაჭერით და უფასო ქვე-დომენით.">
  <meta name="keywords" content="HTML, CSS, JavaScript, PHP, SQL, Hosting, Subdomain">
  <meta name="author" content="Mehrab Mazmanian">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">
    <script>
function ShowPassword() {
  var x = document.getElementById("password");
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}
</script>
<style>
.bg {
  background-image: url("http://<?echo $yourdomain;?>/background.webp");
  background-position: center;
  background-repeat: no-repeat;
}
.input1 {opacity: 0.8;
  background-color: #000000;
  padding: 12px 20px;
  margin: 8px 0;
  border: 1px solid #ffffff;
  border-radius: 10px;
  box-sizing: border-box;
}
.input2 { width: 100%; height: auto;
  padding: 12px 20px;
  margin: 8px 0;
  border: 1px solid #ffffff;
  border-radius: 4px;
  box-sizing: border-box;
}
.div1 { width: 100%; height: auto;
  padding: 12px 20px;
  margin: 8px 0;
  border: 1px solid #ffffff;
  border-radius: 4px;
  box-sizing: border-box;
}
input[type=submit] {
  width: 100%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}

div2 {
  border-radius: 5px;
  padding: 20px;
}
a {text-decoration: none;} 
	</style>
<script>
function validateEmailInput() {
  const emailInput = document.getElementById('emailInput').value;
  const feedbackElement = document.getElementById('emailFeedback');
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  if (emailRegex.test(emailInput)) {
    feedbackElement.textContent = "✔️";
  } else {
    feedbackElement.textContent = "❌";
  }
}
</script>
</head>
<body>
<div class="bg">
<div style="opacity: 0.9;"><a href="http://<?echo $yourdomain;?>"><div style="background-color: black; border-radius: 10px 10px 10px 10px; padding: 8px; margin: 8px; text-align: left; position: fixed; left: 0; top: 0; color: #00ff00; font-size: 20px; text-transform: uppercase; border-left: 5px solid blue; border-right: 5px solid red;"><?echo $yourdomain;?></div></a>
<a href="http://cpanel.<?echo $yourdomain;?>"><div style="background-color: #000000; color: yellow; border-radius: 10px 10px 10px 10px; padding: 8px; margin: 8px; text-align: right; position: fixed; right: 0; top: 0; border-style: double;">
<b>შესვლა</b></div></a></div>
<div class="div2" style="padding: 20px; margin: 20px; text-align: center; color: black; font-size: 20px; text-transform: uppercase;">უფასო ვებ ჰოსტინგი PHP მხარდაჭერით და უფასო ქვე-დომენით</div>
<form method=post action="http://order.<?echo $yourdomain;?>/register2.php"><div style="text-align: center;">
    <div class="input1" style="text-align: left; display: inline-block;"><center><h3 style="color: #00ffff; background-color: #111111;" class="input1">რეგისტრაცია</h3></center><div style="color: #ffffff;" class="div2">ქვე-დომენი</div>
<input placeholder="ქვე-დომენი" type=text style="background-color: #dddddd;" class="input1" name=username value="<?echo $subdomain;?>" pattern="[a-z0-9]{4,16}" maxlength="16" oninvalid="this.setCustomValidity('Enter sub-domain')" oninput="setCustomValidity('')" required><label style="color: #ffffff;"> <small>.<?echo $yourdomain;?></small></label><div style="color: #ffffff;" class="div2">პაროლი</div>
<input placeholder="პაროლი" type=password style="background-color: #dddddd;" class="input1" name=password pattern=".{6,16}" maxlength="16" oninvalid="this.setCustomValidity('Enter password')" oninput="setCustomValidity('')" id="password" required><label for="pass"><input type="checkbox" autocomplete="off" id="pass" onclick="ShowPassword()"><font color="blue"><small>ნახვა</small></font></label><div style="color: #ffffff;" class="div2">ელ. ფოსტა</div>
<input placeholder="ელ. ფოსტა" style="background-color: #dddddd;" class="input1" id="emailInput" oninput="validateEmailInput()" type="email" class="input2" name=email value="" required><label> <small><span id="emailFeedback" style="color: red;">❓</span></small></label><center>
<div class="div2"><input type=hidden name=id value="<?PHP echo $id; ?>"><img alt="captcha" src="http://order.<? echo $yourdomain;?>/image.php?id=<?PHP echo $id; ?>"></div><div style="color: #ffffff;" class="div2">დამცავი კოდი</div>
<input placeholder="კოდი" size="10" type=text style="background-color: #dddddd;" pattern=".{5,5}" class="input1" name=number oninvalid="this.setCustomValidity('Enter security code')" oninput="setCustomValidity('')" required></center>
<center><input type="submit" value="რეგისტრაცია"></center></div></div><center><div style="padding: 14px; margin: 14px; opacity: 0.6;"><a href="https://ifastnet.com/portal/aff.php?aff=30592">ფასიანი ვებ ჰოსტინგი</a></div></center>
<div style="opacity: 0.6;"><div style="padding: 5px; margin: 5px; text-align: left; position: fixed; left: 0; bottom: 0; color: gray;">&copy; 20<?php echo date('y'); ?></div><div style="padding: 5px; margin: 5px; text-align: right; position: fixed; right: 0; bottom: 0;"><?php include 'stat.php'; ?></div></div></div>
</body>
</html>

